package com.example.soap.webservices.demo.soap.exceptions;

public class CourseNotFoundException extends RuntimeException {

	public CourseNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
