package com.example.soap.webservices.demo.soap.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.soap.webservices.demo.soap.bean.Course;

@Component
public class CourseDetailsService {
	
	public enum STATUS{
		
		SUCESS,FAILURE;
	}
	
	private static List<Course> courses = new ArrayList<>();
	
	static {
	Course courseOne = new Course(1,"Biology","Study of biology");
	courses.add(courseOne);
		
	Course courseTwo = new Course(2,"Math","Study of numbers");
	courses.add(courseTwo);
	
	Course courseThree = new Course(3,"English","Study of words");
	courses.add(courseThree);
	
	Course courseFour = new Course(4,"Software","Study of coding");
	courses.add(courseFour);
		
	}
	
	public Course findById(final int id) {
		for(Course course:courses) {
			if(course.getId()==id) {
		return course;}
		
		}
		
		return null;
	}
	
	
	public STATUS deleteById(final int id) {
		
		Iterator<Course> iterator = courses.iterator();
		while(iterator.hasNext()) {
			
			Course course = iterator.next();
			if(course.getId()==id) {
				courses.remove(id);
					return STATUS.SUCESS;
		}
		}
		return STATUS.FAILURE;
	
	}

	public List<Course> getCourses(){
		
		return courses;
	}
}
