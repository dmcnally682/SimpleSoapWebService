package com.example.soap.webservices.demo.soap.soapendpoints;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.example.soap.webservices.demo.soap.bean.Course;
import com.example.soap.webservices.demo.soap.exceptions.CourseNotFoundException;
import com.example.soap.webservices.demo.soap.service.CourseDetailsService;
import com.example.soap.webservices.demo.soap.service.CourseDetailsService.STATUS;

import dmcnallycourses.get_courses.CourseDetails;
import dmcnallycourses.get_courses.DeleteCourseDetailsRequest;
import dmcnallycourses.get_courses.DeleteCourseDetailsResponse;
import dmcnallycourses.get_courses.GetAllCourseDetailsRequest;
import dmcnallycourses.get_courses.GetAllCourseDetailsResponse;
import dmcnallycourses.get_courses.GetCourseDetailsRequest;
import dmcnallycourses.get_courses.GetCourseDetailsResponse;

@Endpoint
public class CourseDetailsEndpoint {
	
	@Autowired
	CourseDetailsService courseDetailsService;
	
	@PayloadRoot(namespace="http://dmcnallyCourses/get_courses", localPart="GetCourseDetailsRequest")
	@ResponsePayload
	public GetCourseDetailsResponse getCourses(@RequestPayload GetCourseDetailsRequest request) throws CourseNotFoundException {
		
	final int id = request.getId();
		Course course = courseDetailsService.findById(id);
		
		if(course == null)
			throw new CourseNotFoundException("Invalid course request" + request.getId());
		
		CourseDetails courseDetails =  mapCourse(course);
		GetCourseDetailsResponse getCourseDetailsResponse = new GetCourseDetailsResponse();
		getCourseDetailsResponse.setCourseDetails(courseDetails);
		return getCourseDetailsResponse;
	}

	private CourseDetails mapCourse(Course course) {
		CourseDetails courseDetails = new CourseDetails();
		courseDetails.setId(course.getId());
		courseDetails.setName(course.getName());
		courseDetails.setDescription(course.getDesc());
	
		
	
	
		
		return courseDetails;
	}

	@PayloadRoot(namespace="http://dmcnallyCourses/get_courses", localPart="GetAllCourseDetailsRequest")
	@ResponsePayload
	public GetAllCourseDetailsResponse getAllCourses(@RequestPayload GetAllCourseDetailsRequest request) {
		
		List<Course> listCourses = courseDetailsService.getCourses();
		GetAllCourseDetailsResponse allCourses = new GetAllCourseDetailsResponse();
		for(Course course: listCourses) {
			CourseDetails courseDetails = mapCourse(course);
			allCourses.getCourseDetails().add(courseDetails);
		}
		return allCourses;
	}
	
	@PayloadRoot(namespace="http://dmcnallyCourses/get_courses", localPart="DeleteCourseDetailsRequest")
	@ResponsePayload
	public DeleteCourseDetailsResponse deleteCourse(@RequestPayload DeleteCourseDetailsRequest request) {
		
		final int id = request.getId();
		final STATUS status = courseDetailsService.deleteById(id);	
		DeleteCourseDetailsResponse deleteCourseDetailsResponse = new DeleteCourseDetailsResponse();
		deleteCourseDetailsResponse.setStatus(mapStatus(status));
		return deleteCourseDetailsResponse;
	}
	
	private dmcnallycourses.get_courses.Status mapStatus(STATUS status) {
		if(status==STATUS.FAILURE) {
			return dmcnallycourses.get_courses.Status.FAILURE;}
		else {
			return dmcnallycourses.get_courses.Status.SUCCESS;}
	}

	
	


}
