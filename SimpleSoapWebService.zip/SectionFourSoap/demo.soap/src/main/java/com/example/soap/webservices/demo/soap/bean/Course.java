package com.example.soap.webservices.demo.soap.bean;

public class Course {
	
	private final int id;
	private final String name;
	private final String desc;
	
	
	
	public Course(int id, String name, String desc) {
		super();
		this.id = id;
		this.name = name;
		this.desc = desc;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getDesc() {
		return desc;
	}

	@Override
	public String toString() {
		return String.format("Course [id=%s, name=%s, desc=%s]", id, name, desc);
	}
	
	
	
	

}
